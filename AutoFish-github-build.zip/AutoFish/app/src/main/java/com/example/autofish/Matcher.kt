package com.example.autofish

import android.graphics.Bitmap
import kotlin.math.abs

class Gray(val w: Int, val h: Int, val d: IntArray)

object Matcher {
    const val SCALE = 4 // images are shrunk 4x before matching (fast + tolerant)

    fun toGray(src: Bitmap): Gray {
        val w = maxOf(1, src.width / SCALE)
        val h = maxOf(1, src.height / SCALE)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== src) small.recycle()
        for (i in px.indices) {
            val c = px[i]
            px[i] = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
        }
        return Gray(w, h, px)
    }

    /**
     * Slides the template over the scene and returns the centre (x, y) in full-res
     * pixels of the best match, or null if nothing is within maxDiff (avg gray diff 0-255).
     */
    fun find(scene: Gray, t: Gray, maxDiff: Int): IntArray? {
        if (t.w < 2 || t.h < 2 || t.w > scene.w || t.h > scene.h) return null
        val cnt = ((t.w + 1) / 2) * ((t.h + 1) / 2) // template sampled every 2nd pixel
        var limit = maxDiff * cnt
        var bx = -1
        var by = -1
        for (y in 0..scene.h - t.h) {
            for (x in 0..scene.w - t.w) {
                var sum = 0
                var ty = 0
                while (ty < t.h && sum < limit) {
                    val so = (y + ty) * scene.w + x
                    val to = ty * t.w
                    var tx = 0
                    while (tx < t.w) {
                        sum += abs(scene.d[so + tx] - t.d[to + tx])
                        tx += 2
                    }
                    ty += 2
                }
                if (sum < limit) { limit = sum; bx = x; by = y }
            }
        }
        return if (bx >= 0) intArrayOf((bx + t.w / 2) * SCALE, (by + t.h / 2) * SCALE) else null
    }
}
