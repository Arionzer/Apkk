package com.example.autofish

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("fish", MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }

        fun addText(s: String, size: Float = 15f): TextView =
            TextView(this).apply { text = s; textSize = size; setPadding(0, 16, 0, 16) }.also { col.addView(it) }

        fun addButton(s: String, f: () -> Unit) {
            col.addView(Button(this).apply { text = s; setOnClickListener { f() } })
        }

        fun slider(label: String, key: String, min: Int, max: Int, def: Int, div: Float) {
            val t = addText("")
            val sb = SeekBar(this)
            sb.max = max - min
            sb.progress = p.getInt(key, def) - min
            t.text = "$label: ${"%.1f".format((sb.progress + min) / div)}"
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, v: Int, u: Boolean) {
                    p.edit().putInt(key, v + min).apply()
                    t.text = "$label: ${"%.1f".format((v + min) / div)}"
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
            col.addView(sb)
        }

        addText("AutoFish", 28f)
        addText(
            "1. Enable the service (Accessibility > Installed apps > AutoFish).\n" +
            "2. Show the floating panel and open your Roblox fishing game.\n" +
            "3. When the bite icon is on screen, tap Snap, drag a box around the icon, then tap where to click (and optionally the recast button).\n" +
            "4. Tap Start."
        )
        addButton("1. Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton("2. Show floating panel") {
            val s = FishService.instance
            if (s == null) Toast.makeText(this, "Enable the service first", Toast.LENGTH_SHORT).show()
            else s.showPanel()
        }
        addText("Match strictness: higher = more forgiving, lower = fewer false clicks")
        slider("Tolerance", "tol", 6, 50, 22, 1f)
        slider("Pause after a catch (s)", "cool", 10, 100, 30, 10f)
        slider("Recast delay (s)", "rdelay", 5, 80, 25, 10f)

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
