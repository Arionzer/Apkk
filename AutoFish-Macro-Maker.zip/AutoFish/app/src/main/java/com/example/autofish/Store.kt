package com.example.autofish

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One thing the macro does: tap, swipe, wait, or tap where the image was found. */
class Act(var t: String, var x: Int = 0, var y: Int = 0, var x2: Int = 0, var y2: Int = 0, var ms: Int = 500) {
    fun toJson(): JSONObject =
        JSONObject().put("t", t).put("x", x).put("y", y).put("x2", x2).put("y2", y2).put("ms", ms)

    fun label(): String = when (t) {
        "TAP" -> "Tap at ($x, $y)"
        "TAP_FOUND" -> "Tap where the image was found"
        "SWIPE" -> "Swipe ($x, $y) to ($x2, $y2) over ${ms} ms"
        "WAIT" -> "Wait ${ms / 1000.0} s"
        else -> t
    }

    companion object {
        fun from(o: JSONObject): Act =
            Act(o.optString("t"), o.optInt("x"), o.optInt("y"), o.optInt("x2"), o.optInt("y2"), o.optInt("ms", 500))
    }
}

/** WHEN (cond) THEN (acts). cond = SEEN, NOT_SEEN or EVERY. cdMs = cooldown (or the interval for EVERY). */
class Rule(
    var cond: String = "SEEN",
    var img: String = "",
    var tol: Int = 22,
    var cdMs: Int = 3000,
    var acts: MutableList<Act> = mutableListOf()
) {
    /** For NOT_SEEN: only fire after the image was seen first, i.e. when it DISAPPEARS. */
    var edge: Boolean = false

    fun toJson(): JSONObject {
        val arr = JSONArray()
        for (a in acts) arr.put(a.toJson())
        return JSONObject().put("cond", cond).put("img", img).put("tol", tol).put("cd", cdMs).put("edge", edge).put("acts", arr)
    }

    fun label(): String {
        val c = when (cond) {
            "SEEN" -> "If '$img' is seen"
            "NOT_SEEN" -> if (edge) "When '$img' disappears" else "If '$img' is NOT seen"
            else -> "Every ${cdMs / 1000.0} s"
        }
        return c + "  >  " + acts.size + " action(s)"
    }

    companion object {
        fun from(o: JSONObject): Rule {
            val r = Rule(o.optString("cond", "SEEN"), o.optString("img"), o.optInt("tol", 22), o.optInt("cd", 3000))
            r.edge = o.optBoolean("edge", false)
            val arr = o.optJSONArray("acts")
            if (arr != null) {
                for (i in 0 until arr.length()) r.acts.add(Act.from(arr.getJSONObject(i)))
            }
            return r
        }
    }
}

class Macro(var id: String, var name: String, var rules: MutableList<Rule> = mutableListOf()) {
    fun toJson(): JSONObject {
        val arr = JSONArray()
        for (r in rules) arr.put(r.toJson())
        return JSONObject().put("id", id).put("name", name).put("rules", arr)
    }

    companion object {
        fun from(o: JSONObject): Macro {
            val m = Macro(o.optString("id"), o.optString("name", "Macro"))
            val arr = o.optJSONArray("rules")
            if (arr != null) {
                for (i in 0 until arr.length()) m.rules.add(Rule.from(arr.getJSONObject(i)))
            }
            return m
        }
    }
}

object Store {
    private fun macroFile(c: Context) = File(c.filesDir, "macros.json")

    fun load(c: Context): MutableList<Macro> {
        val out = mutableListOf<Macro>()
        try {
            val f = macroFile(c)
            if (f.exists()) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) out.add(Macro.from(arr.getJSONObject(i)))
            }
        } catch (e: Exception) {
            // unreadable file: start empty
        }
        return out
    }

    fun save(c: Context, list: List<Macro>) {
        val arr = JSONArray()
        for (m in list) arr.put(m.toJson())
        macroFile(c).writeText(arr.toString())
    }

    fun activeId(c: Context): String =
        c.getSharedPreferences("fish", Context.MODE_PRIVATE).getString("active", "") ?: ""

    fun setActive(c: Context, id: String) {
        c.getSharedPreferences("fish", Context.MODE_PRIVATE).edit().putString("active", id).apply()
    }

    fun imgDir(c: Context): File {
        val d = File(c.filesDir, "imgs")
        d.mkdirs()
        return d
    }

    fun imgFile(c: Context, name: String) = File(imgDir(c), "$name.png")

    fun imgNames(c: Context): List<String> {
        val files = imgDir(c).listFiles() ?: return emptyList()
        return files.filter { it.name.endsWith(".png") }.map { it.name.removeSuffix(".png") }.sorted()
    }

    fun screenFile(c: Context) = File(c.filesDir, "last_screen.png")
}
