# AutoFish (Android 11+)

Image-detecting auto clicker. Uses an Accessibility Service for both
screenshots and taps, so there is no screen-record popup and no overlay permission.

## Build
1. Android Studio > New Project > **Empty Views Activity**
   Name: AutoFish, package: `com.example.autofish`, Language: Kotlin, **Min SDK: 30**.
2. Copy this zip's `app/src/main/` contents over the project's (replace AndroidManifest.xml and MainActivity.kt; add the rest).
3. Run on your phone (USB debugging) or build an APK: Build > Build APK(s).

## First run
1. Open AutoFish > "Open Accessibility settings" > Installed apps > AutoFish > On.
   Android 13+ greys it out for sideloaded apps: Settings > Apps > AutoFish > ⋮ > **Allow restricted settings**, then retry.
2. Back in AutoFish tap "Show floating panel". Open your Roblox game.
3. Cast. When the bite icon is on screen tap **Snap**, drag a box tightly around the icon,
   tap where it should click (or Skip), optionally tap the recast button.
4. Tap **Start**. Tap again to stop.

## Tuning
- Missing bites: raise Tolerance. Clicking at wrong times: lower it.
- Pick a box with distinct shapes/colours, not a flat colour.
- Screenshots are limited to about 3 per second by Android.
