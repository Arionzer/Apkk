# Get the APK without Android Studio
1. Make a free account at github.com, then New repository (any name).
2. Upload everything in this folder (drag the CONTENTS in, including the hidden .github folder).
   Or: Add file > Create new file, name it `.github/workflows/build.yml` and paste that file's text, if the folder gets skipped.
3. Open the Actions tab. The "Build APK" run starts by itself (~3-5 min). Wait for the green check.
4. Click the run > Artifacts > AutoFish-apk. It downloads as a zip; unzip it to get app-debug.apk.
5. Put app-debug.apk on your phone and install it (allow "install unknown apps" when asked).
Then follow README.md for the in-app setup.
