package com.example.autofish

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import java.io.File
import java.util.concurrent.Executors
import kotlin.random.Random

class FishService : AccessibilityService() {

    companion object {
        @Volatile var instance: FishService? = null
        private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences

    private var panel: View? = null
    private var playBtn: TextView? = null
    private var calib: View? = null
    private var calBmp: Bitmap? = null

    @Volatile private var template: Gray? = null
    @Volatile private var busy = false
    private var running = false
    private var pauseUntil = 0L

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("fish", MODE_PRIVATE)
        loadTemplate()
        showPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        panel?.let { runCatching { wm.removeView(it) } }
        closeCalibration()
        instance = null
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun loadTemplate() {
        val f = File(filesDir, "template.png")
        if (!f.exists()) return
        BitmapFactory.decodeFile(f.path)?.let { template = Matcher.toGray(it); it.recycle() }
    }

    // ---------- floating panel ----------
    private fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 16f
        setPadding(28, 18, 28, 18)
        setOnClickListener { onClick() }
    }

    fun showPanel() {
        if (panel != null) return
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xCC202020.toInt())
        }
        val lp = WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 160 }

        val handle = btn("\u283F") {}
        handle.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt()
                        wm.updateViewLayout(row, lp)
                    }
                }
                return true
            }
        })
        playBtn = btn("\u25B6 Start") { toggle() }
        row.addView(handle)
        row.addView(playBtn)
        row.addView(btn("Snap") { startCalibration() })
        row.addView(btn("\u2715") { hidePanel() })
        wm.addView(row, lp)
        panel = row
    }

    private fun hidePanel() {
        running = false
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null; playBtn = null
    }

    // ---------- start / stop ----------
    private fun toggle() {
        if (!running && template == null) { toast("Tap Snap first to pick the bite icon"); return }
        running = !running
        playBtn?.text = if (running) "\u23F8 Stop" else "\u25B6 Start"
        if (running) { busy = false; main.post(tick) }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!busy && System.currentTimeMillis() >= pauseUntil) grab()
            main.postDelayed(this, 350) // Android limits screenshots to ~3 per second
        }
    }

    private fun AccessibilityService.ScreenshotResult.toBitmap(): Bitmap? {
        val hw = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
        hw?.recycle()
        hardwareBuffer.close()
        return bmp
    }

    private fun grab() {
        busy = true
        takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                var hit: IntArray? = null
                try {
                    val bmp = r.toBitmap()
                    val t = template
                    if (bmp != null && t != null) {
                        hit = Matcher.find(Matcher.toGray(bmp), t, prefs.getInt("tol", 22))
                    }
                    bmp?.recycle()
                } catch (e: Exception) { /* ignore frame */ }
                main.post { onResult(hit) }
            }
            override fun onFailure(code: Int) { busy = false }
        })
    }

    private fun onResult(hit: IntArray?) {
        busy = false
        if (!running || hit == null) return
        val cool = prefs.getInt("cool", 30) * 100L
        val rdelay = prefs.getInt("rdelay", 25) * 100L
        val recast = prefs.getBoolean("recast", false)
        val tx = if (prefs.contains("rx")) prefs.getInt("rx", 0) else hit[0]
        val ty = if (prefs.contains("ry")) prefs.getInt("ry", 0) else hit[1]

        pauseUntil = System.currentTimeMillis() + cool + (if (recast) rdelay else 0L)
        main.postDelayed({ tap(tx, ty) }, Random.nextLong(60, 220))
        if (recast) {
            main.postDelayed({
                tap(prefs.getInt("cx", 0), prefs.getInt("cy", 0))
            }, rdelay + Random.nextLong(0, 400))
        }
    }

    private fun tap(x: Int, y: Int) {
        val p = Path().apply {
            moveTo(x + Random.nextInt(-5, 6).toFloat(), y + Random.nextInt(-5, 6).toFloat())
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, Random.nextLong(40, 90)))
            .build()
        dispatchGesture(g, null, null)
    }

    // ---------- calibration ----------
    private fun startCalibration() {
        running = false
        playBtn?.text = "\u25B6 Start"
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val bmp = r.toBitmap()
                if (bmp == null) toast("Screenshot failed") else showCalibration(bmp)
            }
            override fun onFailure(code: Int) { toast("Screenshot failed ($code), try again") }
        })
    }

    private fun showCalibration(bmp: Bitmap) {
        closeCalibration()
        calBmp = bmp
        val root = FrameLayout(this)
        val cv = CalView(bmp)
        root.addView(cv, FrameLayout.LayoutParams(MP, MP))
        val bar = LinearLayout(this).apply { setBackgroundColor(0xCC202020.toInt()) }
        bar.addView(btn("Skip") { cv.skip() })
        bar.addView(btn("Cancel") { closeCalibration() })
        root.addView(bar, FrameLayout.LayoutParams(WC, WC, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = 100 })

        val lp = WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS }
        wm.addView(root, lp)
        calib = root
    }

    private fun closeCalibration() {
        calib?.let { runCatching { wm.removeView(it) } }
        calib = null
        calBmp?.recycle()
        calBmp = null
    }

    private inner class CalView(val bmp: Bitmap) : View(this@FishService) {
        var step = 0 // 0 = box the icon, 1 = click spot, 2 = recast button
        var x0 = 0f; var y0 = 0f; var x1 = 0f; var y1 = 0f
        val boxPaint = Paint().apply { color = Color.GREEN; style = Paint.Style.STROKE; strokeWidth = 5f }
        val textPaint = Paint().apply { color = Color.WHITE; textSize = 44f; setShadowLayer(8f, 0f, 0f, Color.BLACK) }
        val prompts = arrayOf(
            "1/3  Drag a box around the bite icon",
            "2/3  Tap the spot to click (Skip = click the icon)",
            "3/3  Tap the recast button (Skip = no recast)"
        )

        override fun onDraw(c: Canvas) {
            c.drawBitmap(bmp, null, Rect(0, 0, width, height), null)
            if (step == 0) c.drawRect(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1), boxPaint)
            c.drawText(prompts[step], 40f, 140f, textPaint)
        }

        fun skip() {
            if (step == 1) {
                prefs.edit().remove("rx").remove("ry").apply()
                step = 2; invalidate()
            } else if (step == 2) {
                prefs.edit().putBoolean("recast", false).apply()
                done()
            }
        }

        private fun done() { toast("Saved. Press Start"); closeCalibration() }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val fx = bmp.width.toFloat() / width
            val fy = bmp.height.toFloat() / height
            val up = e.action == MotionEvent.ACTION_UP
            when (step) {
                0 -> {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { x0 = e.x; y0 = e.y; x1 = e.x; y1 = e.y }
                        MotionEvent.ACTION_MOVE -> { x1 = e.x; y1 = e.y }
                        MotionEvent.ACTION_UP -> { x1 = e.x; y1 = e.y; saveTemplate(fx, fy) }
                    }
                    invalidate()
                }
                1 -> if (up) {
                    prefs.edit().putInt("rx", (e.x * fx).toInt()).putInt("ry", (e.y * fy).toInt()).apply()
                    step = 2; invalidate()
                }
                2 -> if (up) {
                    prefs.edit().putInt("cx", (e.x * fx).toInt()).putInt("cy", (e.y * fy).toInt())
                        .putBoolean("recast", true).apply()
                    done()
                }
            }
            return true
        }

        private fun saveTemplate(fx: Float, fy: Float) {
            val s = Matcher.SCALE
            val l = (minOf(x0, x1) * fx).toInt() / s * s
            val t = (minOf(y0, y1) * fy).toInt() / s * s
            val r = minOf((maxOf(x0, x1) * fx).toInt() / s * s, bmp.width)
            val b = minOf((maxOf(y0, y1) * fy).toInt() / s * s, bmp.height)
            if (r - l < 24 || b - t < 24) { toast("Box too small, try again"); return }
            val crop = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
            File(filesDir, "template.png").outputStream().use { crop.compress(Bitmap.CompressFormat.PNG, 100, it) }
            template = Matcher.toGray(crop)
            crop.recycle()
            step = 1; invalidate()
        }
    }
}
