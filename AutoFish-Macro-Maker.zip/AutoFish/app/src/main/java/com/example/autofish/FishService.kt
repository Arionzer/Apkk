package com.example.autofish

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.random.Random

class FishService : AccessibilityService() {

    companion object {
        @Volatile var instance: FishService? = null
        private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var wm: WindowManager

    private var panel: View? = null
    private var playBtn: TextView? = null

    // ---- macro runner state ----
    @Volatile private var running = false
    @Volatile private var busy = false      // a screenshot is being taken / matched
    @Volatile private var acting = false    // a rule's actions are being performed
    @Volatile private var runId = 0
    @Volatile private var rules: List<Rule> = emptyList()
    private val templates = HashMap<String, Gray>()
    private val lastFired = HashMap<Rule, Long>()
    private val armed = HashMap<Rule, Boolean>()   // "disappears" rules: image has been seen since last fire
    private val misses = HashMap<Rule, Int>()      // consecutive scans where the image was missing

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        instance = null
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- floating panel ----------
    private fun btn(t: String, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(Color.WHITE)
        v.textSize = 16f
        v.setPadding(28, 18, 28, 18)
        v.setOnClickListener { onClick() }
        return v
    }

    fun showPanel() {
        if (panel != null) return
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setBackgroundColor(0xCC202020.toInt())

        val lp = WindowManager.LayoutParams(
            WC, WC, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 20
        lp.y = 160

        val handle = btn("\u283F") {}
        handle.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f
            var dy = 0f
            var sx = 0
            var sy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - dx).toInt()
                        lp.y = sy + (e.rawY - dy).toInt()
                        wm.updateViewLayout(row, lp)
                    }
                }
                return true
            }
        })
        val play = btn("\u25B6 Start") { toggle() }
        playBtn = play
        row.addView(handle)
        row.addView(play)
        row.addView(btn("Snap") { snap() })
        row.addView(btn("\u2715") { hidePanel() })
        wm.addView(row, lp)
        panel = row
    }

    private fun hidePanel() {
        stop()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        playBtn = null
    }

    // ---------- Snap: save a screenshot for the app to use ----------
    private fun snap() {
        if (running) stop()
        panel?.visibility = View.INVISIBLE
        main.postDelayed({
            takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                    var ok = false
                    try {
                        val bmp = r.toBitmap()
                        if (bmp != null) {
                            Store.screenFile(this@FishService).outputStream().use {
                                bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
                            }
                            bmp.recycle()
                            ok = true
                        }
                    } catch (e: Exception) {
                        ok = false
                    }
                    main.post {
                        panel?.visibility = View.VISIBLE
                        toast(if (ok) "Screen captured! Open AutoFish to use it." else "Screenshot failed, try again")
                    }
                }

                override fun onFailure(code: Int) {
                    main.post {
                        panel?.visibility = View.VISIBLE
                        toast("Screenshot failed ($code), try again")
                    }
                }
            })
        }, 350)
    }

    private fun AccessibilityService.ScreenshotResult.toBitmap(): Bitmap? {
        val hw = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
        val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
        hw?.recycle()
        hardwareBuffer.close()
        return bmp
    }

    // ---------- start / stop ----------
    private fun toggle() {
        if (running) {
            stop()
            return
        }
        val macro = Store.load(this).firstOrNull { it.id == Store.activeId(this) }
        if (macro == null || macro.rules.isEmpty()) {
            toast("Open AutoFish, choose a macro and add at least one rule")
            return
        }
        rules = macro.rules.toList()
        templates.clear()
        var missing = ""
        for (r in rules) {
            if (r.cond == "EVERY") continue
            if (templates.containsKey(r.img)) continue
            val f = Store.imgFile(this, r.img)
            val bmp = if (r.img.isNotEmpty() && f.exists()) BitmapFactory.decodeFile(f.path) else null
            if (bmp == null) {
                missing = r.img
            } else {
                templates[r.img] = Matcher.toGray(bmp)
                bmp.recycle()
            }
        }
        if (missing.isNotEmpty() || rules.any { it.cond != "EVERY" && it.img.isEmpty() }) {
            toast("A rule has no image yet (check your rules). Those rules will be skipped.")
        }
        val now = System.currentTimeMillis()
        lastFired.clear()
        armed.clear()
        misses.clear()
        for (r in rules) if (r.cond == "EVERY") lastFired[r] = now
        busy = false
        acting = false
        runId++
        running = true
        playBtn?.text = "\u23F8 Stop"
        toast("Running: " + macro.name)
        main.removeCallbacks(tick)
        main.post(tick)
    }

    private fun stop() {
        running = false
        acting = false
        main.removeCallbacks(tick)
        playBtn?.text = "\u25B6 Start"
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (!busy && !acting) {
                if (rules.any { it.cond != "EVERY" }) grab() else evaluate(null)
            }
            main.postDelayed(this, 350) // Android limits screenshots to about 3 per second
        }
    }

    private fun key(r: Rule): String = r.img + "|" + r.tol

    // ---------- look at the screen ----------
    private fun grab() {
        busy = true
        val id = runId
        takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val found = HashMap<String, IntArray?>()
                try {
                    val bmp = r.toBitmap()
                    if (bmp != null) {
                        val scene = Matcher.toGray(bmp)
                        bmp.recycle()
                        for (rule in rules) {
                            if (rule.cond == "EVERY") continue
                            val t = templates[rule.img] ?: continue
                            val k = key(rule)
                            if (!found.containsKey(k)) found[k] = Matcher.find(scene, t, rule.tol)
                        }
                    }
                } catch (e: Exception) {
                    // ignore this frame
                }
                main.post {
                    busy = false
                    if (running && id == runId) evaluate(found)
                }
            }

            override fun onFailure(code: Int) {
                main.post { busy = false }
            }
        })
    }

    // ---------- decide which rule fires (top to bottom, first match wins) ----------
    private fun evaluate(found: Map<String, IntArray?>?) {
        val now = System.currentTimeMillis()
        if (found != null) {
            for (r in rules) {
                if (r.cond != "NOT_SEEN" || !r.edge) continue
                val k = key(r)
                if (!found.containsKey(k)) continue
                if (found[k] != null) {
                    armed[r] = true
                    misses[r] = 0
                } else {
                    misses[r] = (misses[r] ?: 0) + 1
                }
            }
        }
        for (r in rules) {
            val last = lastFired[r] ?: 0L
            if (now - last < r.cdMs) continue
            if (r.cond == "EVERY") {
                fire(r, null)
                return
            }
            if (found == null) continue
            val k = key(r)
            if (!found.containsKey(k)) continue // no template or no screenshot: skip
            val hit = found[k]
            if (r.cond == "SEEN" && hit != null) {
                fire(r, hit)
                return
            }
            if (r.cond == "NOT_SEEN" && hit == null) {
                if (r.edge) {
                    // wait until it was seen first, and gone for 2 scans in a row (ignores a one-frame flicker)
                    if (armed[r] != true || (misses[r] ?: 0) < 2) continue
                    armed[r] = false
                }
                fire(r, null)
                return
            }
        }
    }

    private fun fire(r: Rule, hit: IntArray?) {
        acting = true
        lastFired[r] = System.currentTimeMillis()
        exec(r, 0, hit, runId)
    }

    // ---------- do a rule's actions one after another ----------
    private fun exec(r: Rule, i: Int, hit: IntArray?, id: Int) {
        if (!running || id != runId) {
            acting = false
            return
        }
        if (i >= r.acts.size) {
            lastFired[r] = System.currentTimeMillis()
            acting = false
            return
        }
        val a = r.acts[i]
        var delay = 150L
        var jitter = Random.nextLong(40, 160)
        when (a.t) {
            "WAIT" -> {
                delay = a.ms.toLong()
                jitter = 0L
            }
            "TAP" -> tap(a.x, a.y)
            "TAP_FOUND" -> if (hit != null) tap(hit[0], hit[1])
            "SWIPE" -> {
                swipe(a.x, a.y, a.x2, a.y2, a.ms)
                delay = a.ms.toLong() + 150L
            }
        }
        main.postDelayed({ exec(r, i + 1, hit, id) }, delay + jitter)
    }

    private fun tap(x: Int, y: Int) {
        val p = Path()
        p.moveTo(x + Random.nextInt(-5, 6).toFloat(), y + Random.nextInt(-5, 6).toFloat())
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, Random.nextLong(40, 90)))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int) {
        val p = Path()
        p.moveTo(x1.toFloat(), y1.toFloat())
        p.lineTo(x2.toFloat(), y2.toFloat())
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, maxOf(50, ms).toLong()))
            .build()
        dispatchGesture(g, null, null)
    }
}
