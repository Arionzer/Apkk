package com.example.autofish

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Collections
import java.util.UUID

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private var macros: MutableList<Macro> = mutableListOf()
    private var back: (() -> Unit)? = null
    private var refresh: (() -> Unit)? = null

    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        macros = Store.load(this)
        if (serviceOn()) showHome() else showSetup()
    }

    override fun onResume() {
        super.onResume()
        refresh?.invoke()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val f = back
        if (f != null) f() else super.onBackPressed()
    }

    // ---------- small helpers ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun save() = Store.save(this, macros)

    private fun serviceOn(): Boolean {
        if (FishService.instance != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains(packageName) && s.contains("FishService")
    }

    private fun screen(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(40), dp(16), dp(24))
        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
        return col
    }

    private fun LinearLayout.tv(s: String, size: Float = 15f, bold: Boolean = false): TextView {
        val t = TextView(context)
        t.text = s
        t.textSize = size
        t.setPadding(0, dp(6), 0, dp(6))
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        addView(t)
        return t
    }

    private fun LinearLayout.button(s: String, f: () -> Unit): Button {
        val b = Button(context)
        b.text = s
        b.isAllCaps = false
        b.setOnClickListener { f() }
        addView(b)
        return b
    }

    private fun small(s: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.setOnClickListener { f() }
        return b
    }

    private fun LinearLayout.slider(label: String, value: Int, min: Int, max: Int, div: Float, onChange: (Int) -> Unit) {
        val t = tv("")
        val sb = SeekBar(context)
        sb.max = max - min
        sb.progress = value.coerceIn(min, max) - min
        t.text = label + ": " + "%.1f".format((sb.progress + min) / div)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, u: Boolean) {
                t.text = label + ": " + "%.1f".format((v + min) / div)
                onChange(v + min)
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {
                save()
            }
        })
        addView(sb)
    }

    private fun alert(title: String, msg: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Yes") { _, _ -> yes() }
            .setNegativeButton("No", null)
            .show()
    }

    private fun askText(title: String, def: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.setText(def)
        et.setSingleLine()
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ ->
                val v = et.text.toString().trim()
                if (v.isNotEmpty()) onOk(v)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askNumber(title: String, def: String, onOk: (Double) -> Unit) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        et.setText(def)
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ ->
                val v = et.text.toString().trim().toDoubleOrNull()
                if (v == null || v < 0) toast("Please type a number") else onOk(v)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openSettings(i: Intent) {
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("Couldn't open that screen. Open it manually from Android Settings.")
        }
    }

    // ---------- setup / permissions ----------
    private fun showSetup() {
        back = { showHome() }
        refresh = { showSetup() }
        val col = screen()
        col.tv("Setup", 26f, true)
        col.tv(
            "AutoFish needs ONE permission: the Accessibility service. It is how the app can see your screen " +
                "and tap or swipe for you. It only acts while you press Start, and nothing is sent anywhere " +
                "(this app has no internet permission)."
        )

        val on = serviceOn()
        col.tv(if (on) "\u2705 Step 1: Accessibility service is ON" else "\u274C Step 1: Accessibility service is OFF", 18f, true)
        col.tv("Tap the button, open Installed apps (or Downloaded apps), choose AutoFish, switch it ON and accept the warning.")
        col.button("Open Accessibility settings") {
            openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        col.tv("Step 2: Only if the switch is greyed out", 18f, true)
        col.tv("Android 13+ blocks apps installed outside the Play Store. Tap the button, then the three dots (top right) > Allow restricted settings. Go back and redo step 1.")
        col.button("Open AutoFish app info") {
            openSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
        }

        col.tv("Step 3 (optional): Keep it alive", 18f, true)
        col.tv("Set AutoFish to Unrestricted / Don't optimise battery so Android doesn't stop it while you play.")
        col.button("Open battery settings") {
            openSettings(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        if (on) {
            col.button("Continue \u2192") { showHome() }
        } else {
            col.tv("Finish step 1 and this screen will unlock.")
        }
    }

    // ---------- guide ----------
    private fun showGuide() {
        back = { showHome() }
        refresh = null
        val col = screen()
        col.tv("How to use AutoFish", 26f, true)
        col.tv(
            "HOW IT WORKS\n" +
                "You build RULES. A rule says: WHEN something is true, THEN do these actions. " +
                "While running, AutoFish looks at the screen about 3 times a second and checks your rules from top to bottom. " +
                "The first rule that is true runs its actions, then waits for its cooldown.\n\n" +
                "STEP 1: Permissions\n" +
                "Home > Permissions / setup. Turn the Accessibility service on.\n\n" +
                "STEP 2: Make a macro\n" +
                "Home > + New macro. Give it a name.\n\n" +
                "STEP 3: Capture your game screen\n" +
                "Home > Show floating panel. Open your game and get the thing you want to detect on screen. " +
                "Tap Snap on the floating panel (it hides itself for the shot). Then switch back to AutoFish.\n\n" +
                "STEP 4: Make an image\n" +
                "Open the macro > + Add rule > Pick image > Crop a new image. " +
                "Drag a box TIGHTLY around the icon, button or shape you want to detect and name it. " +
                "Pick something with distinct shapes or colours, not a flat colour.\n\n" +
                "STEP 5: Choose the condition\n" +
                "\u2022 Image IS seen: runs when the image is on screen.\n" +
                "\u2022 Image is NOT seen: runs when the image is missing.\n" +
                "\u2022 Every N seconds: runs on a timer, no image needed.\n\n" +
                "STEP 6: Add actions\n" +
                "Tap a spot, tap where the image was found, swipe, or wait. " +
                "To choose a spot, take a fresh Snap of the right screen first, then pick the spot on it.\n\n" +
                "STEP 7: Run\n" +
                "Open the macro and press \"Use this macro\". Open your game and tap Start on the floating panel. Tap Stop to stop.\n\n" +
                "EXAMPLES\n" +
                "Auto fisher (icon appears): IF 'bite' is seen > Tap where the image was found, Wait 2 s, Tap the recast button. Cooldown 3 s.\n" +
                "Auto fisher (text disappears): Crop the text that shows while waiting, e.g. 'waiting'. Rule: image is NOT seen, keep 'Only after it was seen first' ticked > Tap the reel/catch spot, Wait 2 s, Tap the recast button. Cooldown 3 s.\n" +
                "Ad closer: IF 'close_x' is seen > Tap where the image was found.\n" +
                "Timer: EVERY 30 s > Tap the collect button.\n" +
                "Fallback: Rule 1 IF 'menu' is seen > do A. Rule 2 IF 'menu' is NOT seen > do B.\n\n" +
                "TIPS\n" +
                "\u2022 Missing detections: raise Match tolerance. Clicking at the wrong time: lower it.\n" +
                "\u2022 Drag the floating panel away from anything you want detected.\n" +
                "\u2022 Don't rotate the screen: spots are saved for the orientation you captured.\n" +
                "\u2022 Images and spots only work on the phone (and screen size) they were captured on."
        )
        col.button("Back") { showHome() }
    }

    // ---------- home ----------
    private fun showHome() {
        back = null
        refresh = { showHome() }
        val col = screen()
        col.tv("AutoFish Macro Maker", 26f, true)
        if (serviceOn()) {
            col.tv("\u2705 Permission is on. Ready.")
        } else {
            col.tv("\u26A0 Permission needed before anything can run.")
            col.button("Finish setup") { showSetup() }
        }
        val active = macros.firstOrNull { it.id == Store.activeId(this) }
        col.tv("Active macro: " + (active?.name ?: "none (open a macro and choose it)"))
        col.button("Show floating panel (Start / Snap)") {
            val s = FishService.instance
            if (s == null) toast("Enable the service first (Permissions / setup)") else s.showPanel()
        }

        col.tv("Your macros", 18f, true)
        for (m in macros) {
            val star = if (active != null && m.id == active.id) "\u2605 " else ""
            col.button(star + m.name + "  (" + m.rules.size + " rules)") { showEditor(m) }
        }
        col.button("+ New macro") {
            askText("Name your macro", "My macro") { name ->
                val m = Macro(UUID.randomUUID().toString(), name)
                macros.add(m)
                if (Store.activeId(this).isEmpty()) Store.setActive(this, m.id)
                save()
                showEditor(m)
            }
        }
        col.button("How to use (guide)") { showGuide() }
        col.button("Permissions / setup") { showSetup() }
    }

    // ---------- macro editor ----------
    private fun showEditor(m: Macro) {
        back = { showHome() }
        refresh = null
        val col = screen()
        col.tv(m.name, 24f, true)
        col.button("Rename") {
            askText("Rename macro", m.name) { n ->
                m.name = n
                save()
                showEditor(m)
            }
        }
        val isActive = Store.activeId(this) == m.id
        col.button(if (isActive) "\u2605 This is the active macro" else "Use this macro when I press Start") {
            Store.setActive(this, m.id)
            showEditor(m)
        }
        col.tv("Rules are checked top to bottom, over and over. The first rule that is true runs its actions, then waits for its cooldown.")

        col.tv("Rules", 18f, true)
        if (m.rules.isEmpty()) col.tv("No rules yet.")
        for ((i, r) in m.rules.withIndex()) {
            col.button((i + 1).toString() + ". " + r.label()) { showRule(m, r) }
        }
        col.button("+ Add rule") {
            val r = Rule()
            m.rules.add(r)
            save()
            showRule(m, r)
        }

        col.tv("Images", 18f, true)
        col.button("Manage images (" + Store.imgNames(this).size + ")") { showImages { showEditor(m) } }
        col.button("Delete this macro") {
            confirm("Delete '" + m.name + "' and all its rules?") {
                macros.remove(m)
                if (Store.activeId(this) == m.id) Store.setActive(this, "")
                save()
                showHome()
            }
        }
        col.button("Back") { showHome() }
    }

    // ---------- rule editor ----------
    private fun condLabel(r: Rule): String = when (r.cond) {
        "SEEN" -> "WHEN: an image IS seen  (tap to change)"
        "NOT_SEEN" -> "WHEN: an image is NOT seen  (tap to change)"
        else -> "WHEN: every N seconds  (tap to change)"
    }

    private fun showRule(m: Macro, r: Rule) {
        back = { showEditor(m) }
        refresh = null
        val col = screen()
        col.tv("Rule " + (m.rules.indexOf(r) + 1), 24f, true)

        col.button(condLabel(r)) {
            val items = arrayOf("An image IS seen on screen", "An image is NOT seen on screen", "Every N seconds (no image)")
            val codes = arrayOf("SEEN", "NOT_SEEN", "EVERY")
            AlertDialog.Builder(this).setTitle("Condition").setItems(items) { _, which ->
                r.cond = codes[which]
                if (r.cond == "EVERY" && r.cdMs < 500) r.cdMs = 5000
                if (r.cond == "NOT_SEEN") r.edge = true
                save()
                showRule(m, r)
            }.show()
        }

        if (r.cond != "EVERY") {
            col.button(if (r.img.isEmpty()) "Pick image..." else "Image: " + r.img + "  (tap to change)") { pickImage(m, r) }
            val f = Store.imgFile(this, r.img)
            if (r.img.isNotEmpty() && f.exists()) {
                val iv = ImageView(this)
                iv.setImageBitmap(BitmapFactory.decodeFile(f.path))
                iv.adjustViewBounds = true
                iv.maxHeight = dp(120)
                iv.scaleType = ImageView.ScaleType.FIT_START
                col.addView(iv)
            }
            col.slider("Match tolerance (higher = more forgiving)", r.tol, 6, 50, 1f) { r.tol = it }
            if (r.cond == "NOT_SEEN") {
                val cb = CheckBox(this)
                cb.text = "Only after it was seen first (use this when text or an icon DISAPPEARS)"
                cb.isChecked = r.edge
                cb.setOnCheckedChangeListener { _, checked ->
                    r.edge = checked
                    save()
                }
                col.addView(cb)
            }
        }

        val cdLabel = if (r.cond == "EVERY") "Run every (seconds)" else "Wait after it runs (seconds)"
        col.slider(cdLabel, r.cdMs / 100, if (r.cond == "EVERY") 5 else 0, 600, 10f) { r.cdMs = it * 100 }

        col.tv("THEN do these actions, in order", 18f, true)
        if (r.acts.isEmpty()) col.tv("No actions yet.")
        for ((i, a) in r.acts.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val t = TextView(this)
            t.text = (i + 1).toString() + ". " + a.label()
            t.textSize = 14f
            row.addView(t, LinearLayout.LayoutParams(0, WC, 1f))
            row.addView(small("\u2191") {
                if (i > 0) {
                    Collections.swap(r.acts, i, i - 1)
                    save()
                    showRule(m, r)
                }
            })
            row.addView(small("\u2193") {
                if (i < r.acts.size - 1) {
                    Collections.swap(r.acts, i, i + 1)
                    save()
                    showRule(m, r)
                }
            })
            row.addView(small("\u2715") {
                r.acts.removeAt(i)
                save()
                showRule(m, r)
            })
            col.addView(row)
        }
        col.button("+ Add action") { addAction(m, r) }

        col.tv("Rule order", 18f, true)
        col.button("Move rule up") {
            val i = m.rules.indexOf(r)
            if (i > 0) {
                Collections.swap(m.rules, i, i - 1)
                save()
                showRule(m, r)
            }
        }
        col.button("Move rule down") {
            val i = m.rules.indexOf(r)
            if (i >= 0 && i < m.rules.size - 1) {
                Collections.swap(m.rules, i, i + 1)
                save()
                showRule(m, r)
            }
        }
        col.button("Delete rule") {
            confirm("Delete this rule?") {
                m.rules.remove(r)
                save()
                showEditor(m)
            }
        }
        col.button("Done") { showEditor(m) }
    }

    private fun addAction(m: Macro, r: Rule) {
        val labels = ArrayList<String>()
        val types = ArrayList<String>()
        labels.add("Tap a spot (pick on a screenshot)")
        types.add("TAP")
        if (r.cond == "SEEN") {
            labels.add("Tap where the image was found")
            types.add("TAP_FOUND")
        }
        labels.add("Swipe (pick on a screenshot)")
        types.add("SWIPE")
        labels.add("Wait")
        types.add("WAIT")

        AlertDialog.Builder(this).setTitle("Add action").setItems(labels.toTypedArray()) { _, i ->
            when (types[i]) {
                "TAP_FOUND" -> {
                    r.acts.add(Act("TAP_FOUND"))
                    save()
                    showRule(m, r)
                }
                "WAIT" -> askNumber("Wait how many seconds?", "1") { v ->
                    r.acts.add(Act("WAIT", ms = (v * 1000).toInt()))
                    save()
                    showRule(m, r)
                }
                "TAP" -> openPicker(PickerView.POINT, "Tap the spot to click, then press OK", { showRule(m, r) }) { p, _ ->
                    r.acts.add(Act("TAP", p[0], p[1]))
                    save()
                    showRule(m, r)
                }
                "SWIPE" -> openPicker(PickerView.SWIPE, "Drag from where the swipe starts to where it ends, then press OK", { showRule(m, r) }) { p, _ ->
                    r.acts.add(Act("SWIPE", p[0], p[1], p[2], p[3], 400))
                    save()
                    showRule(m, r)
                }
            }
        }.show()
    }

    // ---------- images ----------
    private fun pickImage(m: Macro, r: Rule) {
        val names = Store.imgNames(this)
        val items = ArrayList<String>(names)
        items.add("+ Crop a new image from my last screenshot")
        AlertDialog.Builder(this).setTitle("Pick image").setItems(items.toTypedArray()) { _, which ->
            if (which < names.size) {
                r.img = names[which]
                save()
                showRule(m, r)
            } else {
                cropImage({ n ->
                    r.img = n
                    save()
                    showRule(m, r)
                }, { showRule(m, r) })
            }
        }.show()
    }

    private fun showImages(backTo: () -> Unit) {
        back = backTo
        refresh = null
        val col = screen()
        col.tv("Saved images", 24f, true)
        col.tv("These are what your rules look for. Make them by tapping Snap on the floating panel in your game, then cropping here.")
        val names = Store.imgNames(this)
        if (names.isEmpty()) col.tv("No images yet.")
        for (n in names) {
            val f = Store.imgFile(this, n)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val iv = ImageView(this)
            iv.setImageBitmap(BitmapFactory.decodeFile(f.path))
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            row.addView(iv, LinearLayout.LayoutParams(dp(60), dp(60)))
            val t = TextView(this)
            t.text = n
            t.textSize = 16f
            t.setPadding(dp(10), 0, 0, 0)
            row.addView(t, LinearLayout.LayoutParams(0, WC, 1f))
            row.addView(small("\u2715") {
                confirm("Delete image '" + n + "'?") {
                    f.delete()
                    showImages(backTo)
                }
            })
            col.addView(row)
        }
        col.button("+ Crop a new image from my last screenshot") {
            cropImage({ showImages(backTo) }, { showImages(backTo) })
        }
        col.button("Back") { backTo() }
    }

    private fun cropImage(onDone: (String) -> Unit, cancel: () -> Unit) {
        openPicker(PickerView.BOX, "Drag a box tightly around what should be detected, then press OK", cancel) { rect, bmp ->
            val s = Matcher.SCALE
            val l = rect[0] / s * s
            val t = rect[1] / s * s
            val rr = minOf(rect[2] / s * s, bmp.width)
            val bb = minOf(rect[3] / s * s, bmp.height)
            if (rr - l < 24 || bb - t < 24) {
                toast("Box too small, drag a bigger one")
            } else {
                var n = 1
                while (Store.imgFile(this, "img" + n).exists()) n++
                askText("Name this image", "img" + n) { raw ->
                    var name = raw.replace(Regex("[^A-Za-z0-9_-]"), "_")
                    if (name.isEmpty()) name = "img" + n
                    val crop = Bitmap.createBitmap(bmp, l, t, rr - l, bb - t)
                    Store.imgFile(this, name).outputStream().use { crop.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    crop.recycle()
                    toast("Saved image '" + name + "'")
                    onDone(name)
                }
            }
        }
    }

    // ---------- screenshot picker ----------
    private fun openPicker(mode: Int, prompt: String, cancel: () -> Unit, ok: (IntArray, Bitmap) -> Unit) {
        val f = Store.screenFile(this)
        if (!f.exists()) {
            alert(
                "No screenshot yet",
                "1. Tap 'Show floating panel' on the home screen.\n" +
                    "2. Open your game so the thing you want is on screen.\n" +
                    "3. Tap Snap on the floating panel.\n" +
                    "4. Come back here and try again."
            )
            return
        }
        val bmp = BitmapFactory.decodeFile(f.path)
        if (bmp == null) {
            toast("Couldn't open the screenshot. Take a new Snap.")
            return
        }
        back = cancel
        refresh = null

        val v = PickerView(this, bmp, mode)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        val head = TextView(this)
        head.text = prompt
        head.setTextColor(Color.WHITE)
        head.textSize = 16f
        head.setPadding(dp(12), dp(36), dp(12), dp(8))
        root.addView(head)
        root.addView(v, LinearLayout.LayoutParams(MP, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val cancelBtn = Button(this)
        cancelBtn.text = "Cancel"
        cancelBtn.setOnClickListener { cancel() }
        val okBtn = Button(this)
        okBtn.text = "OK"
        okBtn.setOnClickListener {
            val res = v.result()
            if (res == null) toast("Select something first") else ok(res, bmp)
        }
        bar.addView(cancelBtn, LinearLayout.LayoutParams(0, WC, 1f))
        bar.addView(okBtn, LinearLayout.LayoutParams(0, WC, 1f))
        root.addView(bar)
        setContentView(root)
    }
}
