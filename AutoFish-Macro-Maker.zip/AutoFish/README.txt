AutoFish Macro Maker (Android 11+)
Build: see the GitHub steps you were given. Install the APK, open the app, follow Setup, then How to use (guide).
