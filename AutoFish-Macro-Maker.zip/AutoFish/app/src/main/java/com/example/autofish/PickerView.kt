package com.example.autofish

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Shows a screenshot and lets the user drag a box, tap a point, or drag a swipe line. Coordinates are in screenshot pixels. */
class PickerView(ctx: Context, val bmp: Bitmap, val mode: Int) : View(ctx) {

    companion object {
        const val BOX = 0
        const val POINT = 1
        const val SWIPE = 2
    }

    private var x0 = 0f
    private var y0 = 0f
    private var x1 = 0f
    private var y1 = 0f
    private var hasSel = false

    private val line = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 5f
        isAntiAlias = true
    }
    private val dot = Paint().apply {
        color = Color.RED
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private fun scaleF(): Float = minOf(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
    private fun offX(): Float = (width - bmp.width * scaleF()) / 2f
    private fun offY(): Float = (height - bmp.height * scaleF()) / 2f

    override fun onDraw(c: Canvas) {
        val s = scaleF()
        val ox = offX()
        val oy = offY()
        c.drawColor(Color.BLACK)
        c.drawBitmap(bmp, null, RectF(ox, oy, ox + bmp.width * s, oy + bmp.height * s), null)
        if (!hasSel) return
        val ax = ox + x0 * s
        val ay = oy + y0 * s
        val bx = ox + x1 * s
        val by = oy + y1 * s
        when (mode) {
            BOX -> c.drawRect(minOf(ax, bx), minOf(ay, by), maxOf(ax, bx), maxOf(ay, by), line)
            POINT -> {
                c.drawLine(ax - 40f, ay, ax + 40f, ay, line)
                c.drawLine(ax, ay - 40f, ax, ay + 40f, line)
                c.drawCircle(ax, ay, 12f, dot)
            }
            else -> {
                c.drawLine(ax, ay, bx, by, line)
                c.drawCircle(ax, ay, 14f, dot)
                c.drawCircle(bx, by, 8f, line)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val s = scaleF()
        if (s <= 0f) return true
        val px = ((e.x - offX()) / s).coerceIn(0f, bmp.width.toFloat())
        val py = ((e.y - offY()) / s).coerceIn(0f, bmp.height.toFloat())
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                x0 = px; y0 = py; x1 = px; y1 = py
                hasSel = true
            }
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                if (mode == POINT) {
                    x0 = px; y0 = py
                } else {
                    x1 = px; y1 = py
                }
            }
        }
        invalidate()
        return true
    }

    /** BOX -> [left, top, right, bottom]; POINT -> [x, y]; SWIPE -> [x1, y1, x2, y2]. Null if nothing chosen. */
    fun result(): IntArray? {
        if (!hasSel) return null
        return when (mode) {
            BOX -> intArrayOf(minOf(x0, x1).toInt(), minOf(y0, y1).toInt(), maxOf(x0, x1).toInt(), maxOf(y0, y1).toInt())
            POINT -> intArrayOf(x0.toInt(), y0.toInt())
            else -> intArrayOf(x0.toInt(), y0.toInt(), x1.toInt(), y1.toInt())
        }
    }
}
